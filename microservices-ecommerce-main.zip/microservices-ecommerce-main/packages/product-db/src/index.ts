export { prisma } from './client' 
export * from "../generated/prisma"